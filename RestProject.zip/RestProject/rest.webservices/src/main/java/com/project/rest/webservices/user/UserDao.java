package com.project.rest.webservices.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class UserDao {
	
	private static List<User> userList = new ArrayList<>();

	private static int usersCount = 3;
	
	static {
		userList.add(new User(1, "Daniel", new Date(12/11/1995)));
		userList.add(new User(2, "Kev", new Date(12/11/1996)));
		userList.add(new User(3, "Conor", new Date(12/10/1993)));
	}
	
	public List<User> findAll(){
		return userList;
	}
	
	public User saveUser(User user) {
		if(user.getId() == null)
			user.setId(++usersCount);
		
	
		userList.add(user);
		return user;
	}
	
	public User findUser(int id) 	{
		for(User user: userList) {
			if(user.getId() == id) {
				return user;
			}
		}
		return null;
	}
	
	public User deleteById(int id) 	{
		Iterator<User> iterator = userList.iterator();
		while(iterator.hasNext()) {
			User user = iterator.next();
			if(user.getId() == id) {
				iterator.remove();
				return user;
			}
		}
		return null;
		
	}
}
