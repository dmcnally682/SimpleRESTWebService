insert into user values(1001, sysdate(), 'Ab');
insert into user values(1002, sysdate(), 'Jill');
insert into user values(1003, sysdate(), 'Jam');
insert into post values(11001, 'My first post', '1001');
insert into post values(11002, 'My second post', '1001');